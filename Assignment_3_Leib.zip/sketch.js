function setup() {
  createCanvas(400, 400);
  frameRate(30)
}

function draw() {
  background(51);
  colorMode(RGB);
  
  let eSize = 7;
  let eLoc = 16;
  let x1 = mouseX;
  let y1 = 80;
  let x2 = sqrt(x1);
  let y2 = 20;
  
  rect(eLoc, eLoc, eSize, eSize);
  rect(eLoc * 2, eLoc * 2, pow(eSize, 2), pow(eSize, 2));
  rect(eLoc * 6, eLoc * 6, pow(eSize, 2.5), pow(eSize, 2.5));
  rect(eLoc * 16, eLoc * 16, pow(eSize, 3), pow(eSize, 3));

  line(0, y2, width, y2);
  
  line(mouseX, y2, mouseX, 400);
  line(0, mouseY, 400, mouseY);
  
  line(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + ' -> ' + mouseX);
}
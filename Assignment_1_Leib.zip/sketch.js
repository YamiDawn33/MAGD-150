function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(51);
  
  noStroke();
  rect(15, 15, 90, 90);
  
  stroke(51);
  strokeWeight(10);
  point(25, 25);
  
  strokeWeight(10);
  strokeJoin(ROUND);
  beginShape();
  vertex(80, 30);
  vertex(60, 40);
  vertex(70, 80);
  endShape();
}
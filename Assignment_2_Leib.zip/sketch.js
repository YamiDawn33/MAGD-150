function setup() {
  createCanvas(128, 128);
}

function draw() 
{
  background(51);
  colorMode(RGB, 255, 255, 255, 1);
  let c = color(249, 215, 130);
  fill(c);
  rect(20, 20, 90, 85); 
  fill('red');
  triangle(114, 114, 114, 10, 10, 10);
  fill('blue');
  quad(30, 31, 114, 10, 90, 90, 40, 85);
  fill('green');
  arc(50, 70, 85, 85, 0, HALF_PI + PI); 
}